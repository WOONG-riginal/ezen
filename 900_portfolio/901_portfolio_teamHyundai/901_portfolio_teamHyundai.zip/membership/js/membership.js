$('#mbs_input button').click(function(){
   $('#mbs_bg').css('display','block');
});
$('.mbs_confirm .mbs_p').click(function(){
   $('#mbs_bg').css('display','none');
});